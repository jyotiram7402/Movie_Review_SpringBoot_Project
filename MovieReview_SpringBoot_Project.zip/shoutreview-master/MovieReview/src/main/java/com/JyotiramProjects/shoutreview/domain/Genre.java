package com.JyotiramProjects.shoutreview.domain;


public enum Genre {

    ACTION,
    COMEDY,
    THRILLER,
    ROMANCE,
    SCI_FI,
    DRAMA,
}
